<!--
  Copyright 2020, Gerwin Klein, Régis Décamps, Steve Rowe
  SPDX-License-Identifier: CC-BY-SA-4.0
-->

This directory contains include files for ant and Makefile builds that are
shared between the JFlex examples.
